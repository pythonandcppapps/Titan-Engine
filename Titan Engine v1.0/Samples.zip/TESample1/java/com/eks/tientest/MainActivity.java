package com.eks.tientest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import core.TitanEngine;
import core.GameObject;
import core.Time;
import input.Input; // Küçük harf paket, büyük harf sınıf
import graphics.Mesh;
import graphics.Light;
import graphics.Graphics;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Motoru Saf GLES ile Başlat
        View engineView = TitanEngine.createView(this);
        setContentView(engineView);

        // 2. Müzik (Eski usul)
        TitanEngine.playMusic("Music.ogg");

        // 3. Sahneyi Kur (GL Thread içinde)
        TitanEngine.runOnGLThread(() -> {
            
            // Shader'ları yükle
            int program = TitanEngine.loadShader("basic.vert", "basic.frag");

            // --- KÜP 1: TAŞ BLOK ---
            GameObject cube1 = new GameObject(1);
            cube1.setProgram(program);
            // Mesh.java'daki o meşhur küpü kullanıyoruz
            cube1.setMesh(Mesh.createCube(program)); 
            cube1.applyTexture(this, "tas.png"); 
            cube1.position[0] = -2.5f; 
            TitanEngine.addObject(cube1);

            // --- KÜP 2: TOPRAK BLOK ---
            GameObject cube2 = new GameObject(2);
            cube2.setProgram(program);
            cube2.setMesh(Mesh.createCube(program));
            cube2.applyTexture(this, "toprak.png"); 
            cube2.position[0] = 2.5f; 
            TitanEngine.addObject(cube2);

            // Kamera ve Işık (Saf GLES Ayarları)
            if (Graphics.getMainCamera() != null) {
                Graphics.getMainCamera().setPosition(0, 0, 12.0f);
            }
            
            if (Light.getMainLight() != null) {
                Light.getMainLight().ambientIntensity = 0.4f;
                Light.getMainLight().direction = new float[]{0.0f, -1.0f, -1.0f};
            }

            // Döngüyü Başlat
            startUpdateThread(cube1, cube2);
        });
    }

    private void startUpdateThread(GameObject c1, GameObject c2) {
        new Thread(() -> {
            while (core.TitanEngine.isRunning()) {
                // 'input.Input' şeklinde tam yol yazıyoruz (import hatasını bypass eder)
                if (input.Input.isTouching) {
                    if (c1 != null) {
                        c1.rotation[1] += input.Input.deltaX * 0.5f;
                        c1.rotation[0] += input.Input.deltaY * 0.5f;
                    }
                }

                if (c2 != null) {
                    c2.rotation[0] += input.Input.gyroX * 2.0f;
                    c2.rotation[1] += input.Input.gyroY * 2.0f;
                }

                try { Thread.sleep(16); } catch (Exception e) { break; }
            }
        }).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        TitanEngine.stop();
    }
}