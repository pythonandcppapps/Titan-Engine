package com.eks.tientest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import core.TitanEngine;
import core.GameObject;
import graphics.Mesh;
import graphics.Light;
import graphics.Graphics;
import physics.Particle;
import physics.Physics;
import input.Input;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View engineView = TitanEngine.createView(this);
        setContentView(engineView);

        TitanEngine.setScene(() -> {
            int program = TitanEngine.loadShader("basic.vert", "basic.frag");

            // KÜP 1: Dinamik Nesne
            GameObject cube1 = new GameObject(1);
            cube1.setProgram(program);
            cube1.setMesh(Mesh.createCube(program));
            cube1.applyTexture(this, "tas.png");
            cube1.position[0] = 0.0f;
            cube1.position[1] = 8.0f; 
            cube1.position[2] = -5.0f;

            Particle cube1Phys = new Particle(cube1.position[0], cube1.position[1], cube1.position[2]);
            TitanEngine.physicsWorld.addParticle(cube1Phys);
            TitanEngine.addObject(cube1);

            // KÜP 2: Statik Zemin
            GameObject cube2 = new GameObject(2);
            cube2.setProgram(program);
            cube2.setMesh(Mesh.createCube(program));
            cube2.applyTexture(this, "toprak.png");
            cube2.position[0] = 0.0f;
            cube2.position[1] = -2.0f; 
            cube2.position[2] = -5.0f;
            cube2.scale[0] = 30.0f; 
            cube2.scale[2] = 30.0f;
            TitanEngine.addObject(cube2);

            if (Graphics.getMainCamera() != null) {
                Graphics.getMainCamera().setPosition(0, 4.0f, 18.0f);
            }
            
            if (Light.getMainLight() != null) {
                Light.getMainLight().ambientIntensity = 0.7f;
                Light.getMainLight().direction = new float[]{0.5f, -1.0f, -0.5f};
            }

            TitanEngine.playMusic("Music.ogg");

            startUpdateThread(cube1, cube1Phys);
        });
    }

    private void startUpdateThread(final GameObject c1, final Particle p1) {
        new Thread(() -> {
            final float FLOOR_Y = -1.0f;
            final float SENSITIVITY = 0.12f;

            while (TitanEngine.isRunning()) {
                // 1. FİZİK SİSTEMİ
                if (c1 != null && p1 != null) {
                    p1.velocity.y = Physics.calculateVelocity(p1.velocity.y, Physics.GRAVITY, Physics.DT);
                    p1.y = Physics.calculatePosition(p1.y, p1.velocity.y, Physics.DT);

                    if (p1.y <= FLOOR_Y) {
                        p1.y = FLOOR_Y;
                        p1.velocity.y = 0; 
                    }

                    c1.position[0] = p1.x;
                    c1.position[1] = p1.y;
                    c1.position[2] = p1.z;
                    
                    // Küpün kendi ekseninde dönmesini engellemek için rotasyonu sıfırda tut
                    c1.rotation[0] = 0;
                    c1.rotation[1] = 0;
                    c1.rotation[2] = 0;
                }

                // 2. KAMERA KONTROLÜ
                if (Input.isTouching) {
                    core.Camera cam = Graphics.getMainCamera();
                    if (cam != null) {
                        // Delta varsa döndür
                        if (Math.abs(Input.deltaX) > 0.1f || Math.abs(Input.deltaY) > 0.1f) {
                            cam.rotation[1] += Input.deltaX * SENSITIVITY;
                            cam.rotation[0] += Input.deltaY * SENSITIVITY;
                            
                            // Pitch (yukarı-aşağı) sınırlaması
                            if (cam.rotation[0] > 80.0f) cam.rotation[0] = 80.0f;
                            if (cam.rotation[0] < -80.0f) cam.rotation[0] = -80.0f;

                            Input.deltaX = 0;
                            Input.deltaY = 0;
                        }
                    }
                }

                // 3. ZIPLAMA KONTROLÜ (Sadece yerdeyken ve dokunulduğunda)
                if (Input.isTouching && p1 != null && p1.y <= FLOOR_Y + 0.1f) {
                    // Physics.java'daki yavaşlatılmış yerçekimine uygun zıplama kuvveti
                    p1.velocity.y = 0.25f; 
                }

                try { Thread.sleep(16); } catch (InterruptedException e) { break; }
            }
        }).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        TitanEngine.stop();
    }
}