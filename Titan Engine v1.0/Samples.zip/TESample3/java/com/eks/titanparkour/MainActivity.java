package com.eks.titanparkour;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import core.TitanEngine;
import core.GameObject;
import graphics.Mesh;
import graphics.Light;
import graphics.Graphics;
import physics.Particle;
import physics.Physics;
import input.Input;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private List<GameObject> platforms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View engineView = TitanEngine.createView(this);
        setContentView(engineView);

        TitanEngine.setScene(() -> {
            int program = TitanEngine.loadShader("basic.vert", "basic.frag");

            // ANA KARAKTER
            GameObject player = new GameObject(1);
            player.setProgram(program);
            player.setMesh(Mesh.createCube(program));
            player.applyTexture(this, "tas.png");
            player.position[1] = 5.0f;

            Particle playerPhys = new Particle(0, 5.0f, 0);
            TitanEngine.physicsWorld.addParticle(playerPhys);
            TitanEngine.addObject(player);

            // PARKUR
            createPlatform(program, 0, -2.0f, 0, 10.0f);
            createPlatform(program, 0, 0.0f, -15.0f, 5.0f);
            createPlatform(program, 8.0f, 2.0f, -30.0f, 5.0f);
            createPlatform(program, -5.0f, 4.0f, -45.0f, 6.0f);
            createPlatform(program, 0, 6.0f, -65.0f, 15.0f);

            if (Graphics.getMainCamera() != null) {
                Graphics.getMainCamera().setPosition(0, 5.0f, 15.0f);
            }
            
            if (Light.getMainLight() != null) {
                Light.getMainLight().ambientIntensity = 0.7f;
                Light.getMainLight().direction = new float[]{0.5f, -1.0f, -0.5f};
            }

            TitanEngine.playMusic("Music.ogg");
            startUpdateThread(player, playerPhys);
        });
    }

    private void createPlatform(int prg, float x, float y, float z, float scale) {
        GameObject p = new GameObject(platforms.size() + 10);
        p.setProgram(prg);
        p.setMesh(Mesh.createCube(prg));
        p.applyTexture(this, "toprak.png");
        p.position[0] = x; p.position[1] = y; p.position[2] = z;
        p.scale[0] = scale; p.scale[2] = scale; p.scale[1] = 0.5f;
        platforms.add(p);
        TitanEngine.addObject(p);
    }

    private void startUpdateThread(final GameObject player, final Particle p1) {
        new Thread(() -> {
            final float SENSITIVITY = 0.12f;
            final float TILT_THRESHOLD = 0.02f; // Ölü bölge
            final float TILT_SPEED_MULTIPLIER = 0.08f; 

            while (TitanEngine.isRunning()) {
                float currentFloorY = -20.0f;
                core.Camera cam = (core.Camera) Graphics.getMainCamera();

                // 1. ZEMİN KONTROLÜ
                for (GameObject plt : platforms) {
                    if (p1.x >= plt.position[0] - plt.scale[0] && p1.x <= plt.position[0] + plt.scale[0] &&
                        p1.z >= plt.position[2] - plt.scale[2] && p1.z <= plt.position[2] + plt.scale[2]) {
                        float topOfPlatform = plt.position[1] + 1.0f;
                        if (p1.y >= topOfPlatform - 0.5f) {
                            currentFloorY = topOfPlatform;
                        }
                    }
                }

                // 2. FİZİK
                p1.velocity.y = Physics.calculateVelocity(p1.velocity.y, Physics.GRAVITY, Physics.DT);
                p1.y = Physics.calculatePosition(p1.y, p1.velocity.y, Physics.DT);

                if (p1.y <= currentFloorY) {
                    p1.y = currentFloorY;
                    p1.velocity.y = 0;
                }

                if (p1.y < -15.0f) {
                    p1.x = 0; p1.y = 5.0f; p1.z = 0;
                    p1.velocity.y = 0;
                }

                // 3. EĞİM İLE HAREKET (GYROSCOPE / ACCELEROMETER)
                // Landscape modunda: gyroX ileri-geri, gyroY sağ-sol
                float moveFwd = -Input.gyroX * TILT_SPEED_MULTIPLIER;
                float moveSide = Input.gyroY * TILT_SPEED_MULTIPLIER;

                if (cam != null) {
                    float[] forward = cam.getForwardVector();
                    float rightX = forward[2];
                    float rightZ = -forward[0];

                    if (Math.abs(moveFwd) > TILT_THRESHOLD) {
                        p1.x += forward[0] * moveFwd;
                        p1.z += forward[2] * moveFwd;
                    }
                    if (Math.abs(moveSide) > TILT_THRESHOLD) {
                        p1.x += rightX * moveSide;
                        p1.z += rightZ * moveSide;
                    }
                }

                // 4. BAKIŞ VE ZIPLAMA (DOKUNMATİK)
                if (Input.isTouching && cam != null) {
                    // Ekranın sağ tarafı bakış kontrolü
                    if (Input.startX > TitanEngine.width / 2f) {
                        cam.rotation[1] += Input.deltaX * SENSITIVITY;
                        cam.rotation[0] += Input.deltaY * SENSITIVITY;
                        
                        if (cam.rotation[0] > 80f) cam.rotation[0] = 80f;
                        if (cam.rotation[0] < -80f) cam.rotation[0] = -80f;
                        
                        Input.deltaX = 0; Input.deltaY = 0;

                        // Zıplama (Sağ tarafa dokunulduğunda ve yerdeyken)
                        if (p1.y <= currentFloorY + 0.1f) {
                            p1.velocity.y = 0.28f;
                        }
                    }
                }

                player.position[0] = p1.x;
                player.position[1] = p1.y;
                player.position[2] = p1.z;

                if (cam != null) {
                    cam.position[0] = p1.x;
                    cam.position[1] = p1.y + 4.0f;
                    cam.position[2] = p1.z + 15.0f;
                }

                try { Thread.sleep(16); } catch (InterruptedException e) { break; }
            }
        }).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        TitanEngine.stop();
    }
}